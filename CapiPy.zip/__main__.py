import src.GUI as GUI

def main():
    GUI.main()
main()